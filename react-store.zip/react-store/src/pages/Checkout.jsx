﻿const Checkout = () => {
  return (
    <>
      <h1>Hello Checkout</h1>
    </>
  );
}

export default Checkout;
