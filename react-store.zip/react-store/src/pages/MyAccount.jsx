﻿const MyAccount = () => {
  return (
    <>
      <h1>Hello MyAccount</h1>
    </>
  );
}

export default MyAccount;
