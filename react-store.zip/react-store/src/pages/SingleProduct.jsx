﻿const SingleProduct = () => {
  return (
    <>
      <h1>Hello SingleProduct</h1>
    </>
  );
}

export default SingleProduct;
