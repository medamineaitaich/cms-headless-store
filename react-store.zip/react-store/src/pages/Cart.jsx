﻿const Cart = () => {
  return (
    <>
      <h1>Hello Cart</h1>
    </>
  );
}

export default Cart;
