﻿const Auth = () => {
  return (
    <>
      <h1>Hello Auth</h1>
    </>
  );
}

export default Auth;
