﻿const Products = () => {
  return (
    <>
      <h1>Hello Products</h1>
    </>
  );
}

export default Products;
