﻿const MyOrders = () => {
  return (
    <>
      <h1>Hello MyOrders</h1>
    </>
  );
}

export default MyOrders;
