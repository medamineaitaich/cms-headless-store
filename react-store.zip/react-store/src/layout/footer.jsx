﻿const Footer = () => {
  return (
    <>
      <h1>Hello Footer</h1>
    </>
  );
}

export default Footer;
