﻿const Navbar = () => {
  return (
    <>
      <h1>Hello Navbar</h1>
    </>
  );
}

export default Navbar;
