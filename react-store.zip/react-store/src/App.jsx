﻿import Navbar from './layout/navbar'

function App() {
  return <Navbar />
}

export default App
